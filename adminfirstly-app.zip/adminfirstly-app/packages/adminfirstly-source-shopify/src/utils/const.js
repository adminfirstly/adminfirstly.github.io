export const INCLUDE_PRESENTMENT_PRICES = {
  "X-Shopify-Api-Features": "include-presentment-prices",
}

export const IGNORE_THRESHOLD = 2
