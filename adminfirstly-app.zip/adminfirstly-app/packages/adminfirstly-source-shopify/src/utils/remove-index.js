export function removeIndex(arr, obj) {
  const index = arr.indexOf(obj)
  arr.splice(index, 1)
}
