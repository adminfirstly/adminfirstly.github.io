# medusa-file-minio

Upload files to a MinIO server.

Learn more about how you can use this plugin in the [documentation](https://docs.medusajs.com/add-plugins/minio).

## Options

```js
{
  endpoint: "minio.server.com",
  bucket: "test",
  access_key_id: "YOUR-ACCESS-KEY",
  secret_access_key: "YOUR-SECRET-KEY",
}
```