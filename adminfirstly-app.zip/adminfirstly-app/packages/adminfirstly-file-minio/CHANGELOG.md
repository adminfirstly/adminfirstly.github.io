# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.0.4](https://github.com/medusajs/medusa/compare/medusa-file-minio@1.0.3...medusa-file-minio@1.0.4) (2022-01-11)

**Note:** Version bump only for package medusa-file-minio





## [1.0.3](https://github.com/medusajs/medusa/compare/medusa-file-minio@1.0.2...medusa-file-minio@1.0.3) (2021-12-29)

**Note:** Version bump only for package medusa-file-minio





## [1.0.2](https://github.com/medusajs/medusa/compare/medusa-file-minio@1.0.1...medusa-file-minio@1.0.2) (2021-12-17)

**Note:** Version bump only for package medusa-file-minio





## 1.0.1 (2021-12-08)

**Note:** Version bump only for package medusa-file-minio
