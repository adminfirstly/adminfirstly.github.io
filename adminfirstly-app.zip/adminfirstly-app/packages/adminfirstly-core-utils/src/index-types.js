export const indexTypes = {
  products: "products",
}
