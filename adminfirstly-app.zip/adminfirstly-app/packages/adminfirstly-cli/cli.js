#!/usr/bin/env node

require("dotenv").config()
require("./dist/index.js")
