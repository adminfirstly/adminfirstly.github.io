module.exports = {
  presets: [["babel-preset-medusa-package"]],
};
